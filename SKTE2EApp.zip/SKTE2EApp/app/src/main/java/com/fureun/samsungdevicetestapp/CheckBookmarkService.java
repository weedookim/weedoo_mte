package com.fureun.samsungdevicetestapp;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.IBinder;
import android.provider.Browser;
import android.util.Log;

public class CheckBookmarkService extends Service {

    private CallInterupter callInterupter;

    @Override
    public IBinder onBind(Intent intent) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void onCreate() {
        // TODO Auto-generated method stub
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // TODO Auto-generated method stub
		Log.d("hosung", "onStartCommand");

        SharedPreferences pref;
        pref = getSharedPreferences("samsun_device_test",Context.MODE_PRIVATE);

        boolean bDetectionEnabled = pref.getBoolean("default_alarm", true);

        int res = super.onStartCommand(intent, flags, startId);
        if(bDetectionEnabled) {
            callInterupter = new CallInterupter(getApplicationContext());
            callInterupter.start();
        }
        else {
            callInterupter.stop();
        }
        return res;

    }


    @Override
    public void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();


        SharedPreferences pref;
        pref = getSharedPreferences("samsun_device_test",Context.MODE_PRIVATE);

        boolean bDetectionEnabled = pref.getBoolean("default_alarm", true);

        if(bDetectionEnabled == false) {
            Log.d("hosung", "onDestroy()");
            callInterupter.stop();
        }


    }

    public void checkBookmark(Context context) {
//		Log.d("fureun", "checkBookmark");
    }
}