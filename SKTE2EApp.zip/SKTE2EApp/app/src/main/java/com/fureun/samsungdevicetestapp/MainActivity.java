package com.fureun.samsungdevicetestapp;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;


public class MainActivity extends ActionBarActivity implements OnClickListener {
	private LinearLayout llSub;
	private TextView tvAlarmTime;
	private TextView tvAlarmTime2;

	private Button btOnOff;
	//private Button btOnOff2;

	private boolean bToggleOnOff = true;
	//private boolean bToggleOnOff2 = false;
	
	SharedPreferences pref;
	SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pref = getSharedPreferences("samsun_device_test",Context.MODE_PRIVATE);
        editor = pref.edit();
        
        bToggleOnOff = pref.getBoolean("default_alarm", true);
        //bToggleOnOff2 = pref.getBoolean("sub_alarm", false);
        
        llSub = (LinearLayout) findViewById(R.id.llSub);
        tvAlarmTime = (TextView) findViewById(R.id.tvAlarmTime);

        btOnOff = (Button) findViewById(R.id.btOnOff);
        btOnOff.setOnClickListener(this);

        tvAlarmTime.setText("모의 상황 훈련을 위한 설정");
        
        if(bToggleOnOff) {
        	btOnOff.setBackgroundResource(R.drawable.toggle_on);
        	setAlarm();
        }else {
        	btOnOff.setBackgroundResource(R.drawable.toggle_off);
        	stopAlarm();
        }

    }

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId()) {
		case R.id.btOnOff :
			if(bToggleOnOff) {
				bToggleOnOff = false;
				editor.putBoolean("default_alarm", bToggleOnOff);
				editor.commit();
				stopAlarm();
				btOnOff.setBackgroundResource(R.drawable.toggle_off);
	        }else {
	        	bToggleOnOff = true;
	        	editor.putBoolean("default_alarm", bToggleOnOff);
				editor.commit();
				setAlarm();
	        	btOnOff.setBackgroundResource(R.drawable.toggle_on);
	        }
			break;

		}
	}
	
	public void setAlarm() {
		Log.d("hosung", "setAlarm");

        Intent intent = new Intent(getApplicationContext(), CheckBookmarkService.class);
        startService(intent);

	}
	
	public void stopAlarm() {
		Log.d("hosung", "stopAlarm");

        Intent intent = new Intent(getApplicationContext(), CheckBookmarkService.class);
        stopService(intent);
	}

}
