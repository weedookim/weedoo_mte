package com.fureun.samsungdevicetestapp;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;


public class MainActivity extends ActionBarActivity implements OnClickListener {
	private LinearLayout llSub;
	private TextView tvAlarmTime;
	private TextView tvAlarmTime2;
//	private TextView tvMiddleLine;
	private Button btOnOff;
	private Button btOnOff2;
//	private TextView tvArrow;
	
//	private boolean bArrowShow = false;
	private boolean bToggleOnOff = true;
	private boolean bToggleOnOff2 = false;
	
	SharedPreferences pref;
	SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pref = getSharedPreferences("samsun_device_test",Context.MODE_PRIVATE);
        editor = pref.edit();
        
        bToggleOnOff = pref.getBoolean("default_alarm", true);
        bToggleOnOff2 = pref.getBoolean("sub_alarm", false);
        
        llSub = (LinearLayout) findViewById(R.id.llSub);
        tvAlarmTime = (TextView) findViewById(R.id.tvAlarmTime);
//        tvAlarmTime2 = (TextView) findViewById(R.id.tvAlarmTime2);
//        tvMiddleLine = (TextView) findViewById(R.id.tvMiddleLine);
        btOnOff = (Button) findViewById(R.id.btOnOff);
//        btOnOff2 = (Button) findViewById(R.id.btOnOff2);
//        tvArrow = (TextView) findViewById(R.id.btArrow);
        btOnOff.setOnClickListener(this);
//        btOnOff2.setOnClickListener(this);
//        tvArrow.setOnClickListener(this);
        
        tvAlarmTime.setText("모의 상황 훈련을 위한 설정");
//        tvAlarmTime2.setText("한 시간 마다 실행");
        
//        if(!bArrowShow) {
//        	tvMiddleLine.setVisibility(View.GONE);
//        }else {
//        	tvMiddleLine.setVisibility(View.VISIBLE);
//        }
        
        if(bToggleOnOff) {
        	btOnOff.setBackgroundResource(R.drawable.toggle_on);
        	//stopAlarm();
        	setAlarm();
        }else {
        	btOnOff.setBackgroundResource(R.drawable.toggle_off);
        	stopAlarm();
        }
        
//        if(bToggleOnOff2) {
//        	btOnOff2.setBackgroundResource(R.drawable.toggle_on);
//        	stopSubAlarm();
//        	setSubAlarm();
//        }else {
//        	btOnOff2.setBackgroundResource(R.drawable.toggle_off);
//        	stopSubAlarm();
//        }
//
    }

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId()) {
		case R.id.btOnOff :
			if(bToggleOnOff) {
				bToggleOnOff = false;
				editor.putBoolean("default_alarm", bToggleOnOff);
				editor.commit();
				stopAlarm();
				btOnOff.setBackgroundResource(R.drawable.toggle_off);
	        }else {
	        	bToggleOnOff = true;
	        	editor.putBoolean("default_alarm", bToggleOnOff);
				editor.commit();
				setAlarm();
	        	btOnOff.setBackgroundResource(R.drawable.toggle_on);
	        }
			break;
//		case R.id.btOnOff2 :
//			if(bToggleOnOff2) {
//				bToggleOnOff2 = false;
//				editor.putBoolean("sub_alarm", bToggleOnOff2);
//				editor.commit();
//				stopSubAlarm();
//				btOnOff2.setBackgroundResource(R.drawable.toggle_off);
//			}else {
//				bToggleOnOff2 = true;
//				editor.putBoolean("sub_alarm", bToggleOnOff2);
//				editor.commit();
//				setSubAlarm();
//				btOnOff2.setBackgroundResource(R.drawable.toggle_on);
//			}
//			break;
//		case R.id.btArrow :
//			break;
		}
	}
	
	public void setAlarm() {
		Log.d("hosung", "setAlarm");
//		AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);


        Intent intent = new Intent(getApplicationContext(), CheckBookmarkService.class);
        startService(intent);
//		PendingIntent operation = PendingIntent.getService(getApplicationContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
//
//		long startTime = getAlarmStartTime(1, 0, 0, 0);
//		long intevalAlarm = 1000 * 60 * 60 * 24 * 7;
//
//		am.setRepeating(AlarmManager.RTC_WAKEUP, startTime, intevalAlarm , operation);






	}
	
	public void setSubAlarm() {
//		AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
//		Intent intent = new Intent(getApplicationContext(), CheckBookmarkService.class);
//		PendingIntent operation = PendingIntent.getService(getApplicationContext(), 1, intent, PendingIntent.FLAG_UPDATE_CURRENT);
//
//		long startTime = System.currentTimeMillis()+ 10000;
//		long intevalAlarm = 1000 * 60 * 60;
//
//		am.setRepeating(AlarmManager.RTC_WAKEUP, startTime, intevalAlarm , operation);

	}
	
	public void stopAlarm() {
		Log.d("hosung", "stopAlarm");
//		AlarmManager alarmManager = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
//
//		Intent intent = new Intent(getApplicationContext(), CheckBookmarkService.class);
//        PendingIntent operation = PendingIntent.getActivity(getApplicationContext(), 0, intent, 0);
//		PendingIntent operation = PendingIntent.getService(getApplicationContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
//        alarmManager.cancel(operation);

        Intent intent = new Intent(getApplicationContext(), CheckBookmarkService.class);
        //PendingIntent operation = PendingIntent.getActivity(getApplicationContext(), 0, intent, 0);
        //ntent.putExtra("value", 0);
        //startService(intent);
        stopService(intent);
	}
	
	public void stopSubAlarm() {
//		Log.d("fureun", "stopAlarm");
		AlarmManager alarmManager = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
		 
		Intent intent = new Intent(getApplicationContext(), CheckBookmarkService.class);
//        PendingIntent operation = PendingIntent.getActivity(getApplicationContext(), 0, intent, 0);
		PendingIntent operation = PendingIntent.getService(getApplicationContext(), 1, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(operation);
	}
	
	public long getAlarmStartTime(int dayofweek, int hour, int minute, int second) {
//		long currentTime = System.currentTimeMillis();
//		Calendar alarmCalendar = Calendar.getInstance();
//
//		alarmCalendar.set(Calendar.DAY_OF_WEEK, dayofweek);
//		alarmCalendar.set(Calendar.HOUR_OF_DAY, hour);
//		alarmCalendar.set(Calendar.MINUTE, minute);
//		alarmCalendar.set(Calendar.SECOND, second);
//		long alarmTime = alarmCalendar.getTimeInMillis();
//
//		if(currentTime > alarmTime) {
//			alarmCalendar.add(Calendar.SECOND, (60*60*24*7));
//		}
//
//		return alarmCalendar.getTimeInMillis();
        return 0;
	}
	
	public String convertMillsToSimpleDateFormat(long mills) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
		Date convertDate = new Date(mills);
		return simpleDateFormat.format(convertDate);

	}
}
