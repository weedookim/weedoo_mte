package com.fureun.samsungdevicetestapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;


import java.lang.reflect.Method;


public class BootCallBR extends BroadcastReceiver {


    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO Auto-generated method stub

        final Context ctx = context.getApplicationContext();

        if(Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
			Log.d("hosung", "ACTION_BOOT_COMPLETED");
            context.startService(new Intent(context, BootStartService.class));
        }

    }
}
