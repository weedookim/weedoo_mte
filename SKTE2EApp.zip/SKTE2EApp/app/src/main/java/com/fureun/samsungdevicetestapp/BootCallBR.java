package com.fureun.samsungdevicetestapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;


import java.lang.reflect.Method;


public class BootCallBR extends BroadcastReceiver {


    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO Auto-generated method stub

        final Context ctx = context.getApplicationContext();

        if(Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
			Log.d("hosung", "ACTION_BOOT_COMPLETED");
            context.startService(new Intent(context, BootStartService.class));
        }

//        if(Intent.ACTION_NEW_OUTGOING_CALL.equals(intent.getAction())) {
//            //Log.d("hosung", "ACTION_NEW_OUTGOING_CALL");
//
//            String number = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER);
//
//            Toast.makeText(ctx,
//                    "Outgoing: "+number,
//                    Toast.LENGTH_LONG).show();
//
//        }
//        else {
//
//            final TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
//
//
//
//            PhoneStateListener phoneStateListener = new PhoneStateListener() {
//
//                @Override
//                public void onCallStateChanged(int state, String incomingNumber) {
//                    //super.onCallStateChanged(state, incomingNumber);
//                    Log.d("hosung", "CALL STATE RINGING");
//                    if (state == TelephonyManager.CALL_STATE_RINGING) {
//                        Toast.makeText(ctx, "Phone is Ringing, I know incomingNumber", Toast.LENGTH_LONG).show();
//                        //context.startService(new Intent(context, BootStartService.class));
//
//
//                    }
//
//                    if (state == TelephonyManager.CALL_STATE_IDLE) {
//                        Toast.makeText(ctx, "Your Phone is On My eyes!!!!", Toast.LENGTH_LONG).show();
//
//                    }
//
//                    if (state == TelephonyManager.CALL_STATE_OFFHOOK) {
//                        Toast.makeText(ctx, "Phone is OFFHOOK !!! ", Toast.LENGTH_LONG).show();
//                    }
//
//                    //if (state == TelephonyManager.CALL_STATE)
//
//                }
//
//
//
//            };
//            telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);
//
//        }


    }
}
